﻿<!DOCTYPE html>
<html lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscripción de Usuario</title>
    <link rel="stylesheet" href="style.css" type="text/css"> <!--Incluye el archivo de estilo (css)-->
</head>
<body>
	<form action="formulario.html" style="margin-bottom:30px">
	 <button class="sm-btn right-btn">Inicio</button>
	</form>
	<?php
		if($_POST){
			//Recuperacion entradas
			$nombre =  $_POST['nombre'];
			$apellido1 = $_POST['apellido1'];
			$apellido2 = $_POST['apellido2'];
			$email = $_POST['email'];
			$pwd = $_POST['pwd'];
			$pwdc = $_POST['pwdc'];

			//Validacion de entradas
			if(!$nombre || !$apellido1 || !$apellido2 || !$email || !$pwd || !$pwdc){
				echo "<div class='divError'><h3>" . 
						"No ha introducido todos los campos obligatorios" .
					"</h3></div>";
				$ok=false;
			} else if(strlen($nombre)>20){
				echo "<div class='divError'><h3>" . 
							"El nombre debe tener maximo 20 caracteres" .
						"</h3></div>";
				$ok=false;
			} else if(strlen($apellido1)>20){
				echo "<div class='divError'><h3>" . 
							"El apellido 1 debe tener maximo 20 caracteres" .
						"</h3></div>";
				$ok=false;
			} else if(strlen($apellido2)>20){
				echo "<div class='divError'><h3>" . 
							"El apellido 2 debe tener maximo 20 caracteres" .
						"</h3></div>";
				$ok=false;
			} else if(strlen($email)>20){
				echo "<div class='divError'><h3>" . 
							"El email debe tener maximo 20 caracteres" .
						"</h3></div>";
				$ok=false;
			} else if(strpos($email, "@")==0 || strpos($email, ".")==0 || strpos($email, ".")==strlen($email) || strpos($email, "@")==strlen($email) || strpos($email, "@")>strpos($email, ".")){
				echo "<div class='divError'><h3>" . 
							"El email no tiene el formato correcto (<small>example@example.es</small>)" .
						"</h3></div>";
				$ok=false;
			} else if($pwd!=$pwdc){
				echo "<div class='divError'><h3>" . 
							"La contraseña y su confirmación no coinciden" .
						"</h3></div>";
				$ok=false;
			} else{
				$ok=true;
			}

			if($ok){
				//Conexion a BD
				$servername = "localhost";
				$username = "root";
				$password = "";
				$dbname = "cursosql";

				$conn = new mysqli($servername, $username, $password, $dbname);
				if($conn->connect_error){
					 echo "Fallo de conexión: " . $conn->connect_error;
				} else{
					//Comprobacion EMAIL coincidente
					$sqlquery= "SELECT COUNT(1) FROM usuario WHERE email = '$email'";
					if($conn->query($sqlquery) === TRUE){
						$conn->close();
						echo "<div class='divError'><h3>" . 
								"No se ha podido comprobar la existencia de registros coincidentes <small>(" . $sqlquery . "<br>" . $conn->error . ")</small>" .
							"</h3></div>";
					} else {
						if($conn->query($sqlquery)->fetch_row()[0]>0){
							$conn->close();
							echo "<div class='divError'><h3>" . 
									"Ya existe un usuario con el correo facilitado: " . $email . 
								"</h3></div>";
						} else {
							//Registro en BD
							$sqlquery= "INSERT INTO usuario (nombre, apellido1, apellido2, email, password) VALUES ('$nombre', '$apellido1', '$apellido2', '$email', '$pwd')";
							if($conn->query($sqlquery) === TRUE){
								//Satisfactorio, devuelve nuevo archivo html
								$contents = file_get_contents('success.html');
								echo $contents;
							} else {
								echo "<div class='divError'><h3>" . 
										"No se ha podido suscribir el usuario <small>(" . $sqlquery . "<br>" . $conn->error . ")</small>" .
									"</h3></div>";
							}

							$conn->close();
						}
					}
				}
			}
		}
	?>

	<footer>
    <!--Informaci�n adicional-->
    <div>
        <hr />
        <span>&copy; 2023 Carmen Romero Saiz</span>
    </div>
	</footer>
</body>
</html>

