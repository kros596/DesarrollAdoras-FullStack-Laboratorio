﻿<!DOCTYPE html>
<html lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <link rel="stylesheet" href="style.css" type="text/css"> <!--Incluye el archivo de estilo (css)-->
</head>
<body>
	<form action="formulario.html" style="margin-bottom:30px">
	 <button class="sm-btn right-btn">Inicio</button>
	</form>
	<div class="container">
	<?php
		if($_POST){
			//Conexion a BD
			$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "cursosql";

			$conn = new mysqli($servername, $username, $password, $dbname);
			if($conn->connect_error){
			die("<div class='divError'>Fallo de conexión: " . $conn->connect_error . "</div>");
			}

			//Seleccion de datos (menos contraseña, que no sería seguro)
			$sqlquery= "SELECT NOMBRE, APELLIDO1, APELLIDO2, EMAIL FROM usuario";
			if($conn->query($sqlquery) === TRUE){
				$conn->close();
				die("<div class='divError'><h3>" . 
						"No se han podido recuperar los datos <small>(". $conn->error . ")</small>" .
					"</h3><div>");
			} else {
				$filas = $conn->query($sqlquery)->fetch_all();
				if(count($filas)==0){
					die("<div class='divError'><h3>" . 
							"No se han encontrado registros" .
						"</h3><div>");
				}
				$content ="<h1 class='title'>Usuarios</h1>" . 
							  "<table>" .
								"<thead><tr><th>NOMBRE</th><th>APELLIDO1</th><th>APELLIDO2</th><th>EMAIL</th></tr></thead>" .
								"<tbody>";
				foreach ($filas as &$fila) {
					$content .= "<tr>";
					foreach($fila as &$campo){
						$content .= "<td>" . $campo . "</td>";
					}
					$content .= "</tr>";
				}
				$content .= "</tbody>";
				$content .= "</table>";

				echo $content;
			}

			$conn->close();		}
	?>
	</div>

	 <footer>
        <!--Informaci�n adicional-->
        <div>
            <hr />
            <span>&copy; 2023 Carmen Romero Saiz</span>
        </div>
    </footer>
</body>
</html>


